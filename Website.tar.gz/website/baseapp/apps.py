from django.apps import AppConfig


class BaseappConfig(AppConfig):
    name = 'baseapp'
